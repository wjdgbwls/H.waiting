
package com.bs.lec01.Member;

public class Member {
	private String tnum="";
	public String getTnum() {
		return tnum;
	}

	public void setTnum(String tnum) {
		this.tnum = tnum;
	}

	public String getDnum() {
		return dnum;
	}

	public void setDnum(String dnum) {
		this.dnum = dnum;
	}

	private String dnum="";
	private String field ="";
	private String value ="";
	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	private String m_num = "";
	public String getM_num() {
		return m_num;
	}

	public void setM_num(String m_num) {
		this.m_num = m_num;
	}

	private String name = "";
	private String gender = "";									
	private String place = "";
	private String age="";
	
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	private String Citizen_num ="";

	private String phone = "";
	private String dateInserted= "";
	/*
	 * private String userID= ""; private String userPassword= "";
	 */
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getCitizen_num() {
		return Citizen_num;
	}

	public void setCitizen_num(String citizen_num) {
		Citizen_num = citizen_num;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDateInserted() {
		return dateInserted;
	}

	public void setDateInserted(String dateInserted) {
		this.dateInserted = dateInserted;
	}
	/*
	 * public String getUserID() { return userID; }
	 * 
	 * public void setUserID(String userID) { this.userID = userID; }
	 * 
	 * public String getUserPassword() { return userPassword; }
	 * 
	 * public void setUserPassword(String userPassword) { this.userPassword =
	 * userPassword; }
	 */

	
	
	
	
	public Member(){
	}
				



	}
